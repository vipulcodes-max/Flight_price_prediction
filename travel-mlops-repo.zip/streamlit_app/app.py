"""Streamlit dashboard: travel insights + hotel recommendations."""
import streamlit as st
import pandas as pd
import joblib
import os

st.set_page_config(page_title="Travel Recommender", page_icon="🏨", layout="wide")

BASE = os.path.dirname(__file__)

@st.cache_resource
def load_artifacts():
    art = joblib.load(os.path.join(BASE, "..", "models", "hotel_recommender.pkl"))
    hotels = pd.read_csv(os.path.join(BASE, "..", "data", "hotels.csv"))
    return art, hotels

art, hotels = load_artifacts()
user_item, item_sim, popularity = art["user_item"], art["item_sim"], art["popularity"]

st.title("🏨 Travel Hotel Recommender")
st.caption("Item-based collaborative filtering on 40k stays • popularity fallback for new users")

tab1, tab2, tab3 = st.tabs(["Recommendations", "Hotel Insights", "Data Explorer"])

with tab1:
    col1, col2 = st.columns([1, 2])
    with col1:
        user_code = st.number_input("User code", min_value=0, value=0, step=1)
        top_n = st.slider("Number of recommendations", 1, 5, 3)
        go = st.button("Recommend", type="primary")
    with col2:
        if go:
            if user_code in user_item.index:
                history = user_item.loc[user_code]
                scores = item_sim.mul(history, axis=0).sum(axis=0)
                scores = scores[history == 0]
                recs = (scores.nlargest(top_n).index.tolist()
                        if not scores.empty else popularity.head(top_n).index.tolist())
                st.subheader("Based on your stay history")
                visited = history[history > 0].sort_values(ascending=False)
                st.write("Past stays (nights):", visited.to_dict())
            else:
                recs = popularity.head(top_n).index.tolist()
                st.subheader("New user — most popular hotels")
            for i, name in enumerate(recs, 1):
                row = popularity.loc[name]
                st.metric(f"#{i}  {name}", f"₹{row['avg_price']:.0f}/night", f"{row['place']}")

with tab2:
    st.subheader("Popularity & pricing")
    st.bar_chart(popularity["stays"])
    st.dataframe(popularity.style.format({"avg_price": "{:.2f}"}))
    st.subheader("Hotel–hotel similarity (cosine)")
    st.dataframe(item_sim.style.background_gradient(cmap="Blues").format("{:.2f}"))

with tab3:
    place = st.multiselect("Filter by place", sorted(hotels["place"].unique()))
    view = hotels[hotels["place"].isin(place)] if place else hotels
    st.dataframe(view.head(500))
    st.download_button("Download filtered CSV", view.to_csv(index=False), "hotels_filtered.csv")
