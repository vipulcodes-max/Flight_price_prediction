"""Smoke tests for the Flask API (run in CI)."""
import json
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from api.app import app

client = app.test_client()

def test_health():
    assert client.get("/health").status_code == 200

def test_predict_ok():
    payload = {"from": "Recife (PE)", "to": "Florianopolis (SC)", "flightType": "firstClass",
               "agency": "FlyingDrops", "time": 1.76, "distance": 676.53}
    r = client.post("/predict", data=json.dumps(payload), content_type="application/json")
    assert r.status_code == 200
    assert "predictions" in r.get_json()

def test_predict_missing_field():
    r = client.post("/predict", data=json.dumps({"from": "X"}), content_type="application/json")
    assert r.status_code == 400
