"""Airflow DAG: weekly retraining pipeline for the flight price model.

Stages: extract -> validate -> preprocess/train -> evaluate -> register (MLflow)
"""
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator

DATA_PATH = "/opt/airflow/data/flights.csv"
MODEL_PATH = "/opt/airflow/models/flight_price_model.pkl"

def extract_data(**ctx):
    import pandas as pd
    df = pd.read_csv(DATA_PATH)
    print(f"Extracted {len(df)} rows")
    ctx["ti"].xcom_push(key="n_rows", value=len(df))

def validate_data(**ctx):
    import pandas as pd
    df = pd.read_csv(DATA_PATH)
    assert df["price"].notna().all(), "Null prices found"
    assert (df["price"] > 0).all(), "Non-positive prices found"
    required = {"from", "to", "flightType", "agency", "time", "distance", "price"}
    assert required.issubset(df.columns), "Schema drift detected"
    print("Validation passed")

def train_model(**ctx):
    import pandas as pd, joblib
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import OneHotEncoder
    from sklearn.compose import ColumnTransformer
    from sklearn.pipeline import Pipeline
    from sklearn.ensemble import RandomForestRegressor

    df = pd.read_csv(DATA_PATH)
    X = df[["from", "to", "flightType", "agency", "time", "distance"]]
    y = df["price"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    pipe = Pipeline([
        ("pre", ColumnTransformer(
            [("cat", OneHotEncoder(handle_unknown="ignore"),
              ["from", "to", "flightType", "agency"])], remainder="passthrough")),
        ("model", RandomForestRegressor(n_estimators=25, max_depth=25, n_jobs=-1, random_state=42)),
    ])
    pipe.fit(X_train, y_train)
    joblib.dump(pipe, MODEL_PATH, compress=3)
    ctx["ti"].xcom_push(key="r2", value=float(pipe.score(X_test, y_test)))

def evaluate_model(**ctx):
    r2 = ctx["ti"].xcom_pull(key="r2", task_ids="train_model")
    print(f"Test R2 = {r2:.4f}")
    assert r2 > 0.85, f"Model below quality gate (R2={r2:.4f}) - deployment blocked"

def register_model(**ctx):
    import mlflow, joblib
    mlflow.set_tracking_uri("http://mlflow:5000")
    mlflow.set_experiment("flight-price-regression")
    with mlflow.start_run(run_name="airflow_scheduled_retrain"):
        mlflow.log_metric("r2", ctx["ti"].xcom_pull(key="r2", task_ids="train_model"))
        mlflow.sklearn.log_model(joblib.load(MODEL_PATH), "model")

default_args = {"owner": "mlops", "retries": 1, "retry_delay": timedelta(minutes=5)}

with DAG(
    dag_id="flight_price_retraining",
    default_args=default_args,
    description="Weekly retraining of the flight price regression model",
    schedule_interval="@weekly",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=["mlops", "regression"],
) as dag:
    t1 = PythonOperator(task_id="extract_data", python_callable=extract_data)
    t2 = PythonOperator(task_id="validate_data", python_callable=validate_data)
    t3 = PythonOperator(task_id="train_model", python_callable=train_model)
    t4 = PythonOperator(task_id="evaluate_model", python_callable=evaluate_model)
    t5 = PythonOperator(task_id="register_model", python_callable=register_model)

    t1 >> t2 >> t3 >> t4 >> t5
