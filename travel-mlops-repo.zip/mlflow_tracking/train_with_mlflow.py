"""Standalone training script with full MLflow experiment tracking.

Usage:  mlflow ui   (in another terminal)
        python mlflow_tracking/train_with_mlflow.py
"""
import mlflow
import mlflow.sklearn
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

df = pd.read_csv("data/flights.csv")
X = df[["from", "to", "flightType", "agency", "time", "distance"]]
y = df["price"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

pre = ColumnTransformer(
    [("cat", OneHotEncoder(handle_unknown="ignore"), ["from", "to", "flightType", "agency"])],
    remainder="passthrough")

mlflow.set_experiment("flight-price-regression")

candidates = {
    "linear_regression": LinearRegression(),
    "random_forest": RandomForestRegressor(n_estimators=25, max_depth=25, n_jobs=-1, random_state=42),
}

for name, model in candidates.items():
    with mlflow.start_run(run_name=name):
        pipe = Pipeline([("pre", pre), ("model", model)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        metrics = {"r2": r2_score(y_test, pred),
                   "mae": mean_absolute_error(y_test, pred),
                   "rmse": float(np.sqrt(mean_squared_error(y_test, pred)))}
        mlflow.log_params(model.get_params())
        mlflow.log_metrics(metrics)
        mlflow.sklearn.log_model(pipe, "model",
                                 registered_model_name="flight-price-model" if name == "random_forest" else None)
        print(name, metrics)
