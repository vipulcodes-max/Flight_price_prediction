"""Flask REST API serving the flight price prediction model."""
from flask import Flask, request, jsonify
import joblib
import pandas as pd
import os

app = Flask(__name__)
MODEL_PATH = os.getenv("MODEL_PATH", os.path.join(os.path.dirname(__file__), "..", "models", "flight_price_model.pkl"))
model = joblib.load(MODEL_PATH)

FEATURES = ["from", "to", "flightType", "agency", "time", "distance"]

@app.route("/", methods=["GET"])
def home():
    return jsonify({"service": "Flight Price Prediction API", "status": "running",
                    "usage": "POST /predict with JSON: " + str(FEATURES)})

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "healthy"}), 200

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json(force=True)
    rows = data if isinstance(data, list) else [data]
    missing = [f for f in FEATURES for r in rows if f not in r]
    if missing:
        return jsonify({"error": f"missing fields: {sorted(set(missing))}"}), 400
    X = pd.DataFrame(rows)[FEATURES]
    preds = model.predict(X)
    return jsonify({"predictions": [round(float(p), 2) for p in preds]})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
