# Travel MLOps Capstone

End-to-end MLOps project: flight price regression, gender classification and a hotel
recommender, deployed through Flask → Docker → Kubernetes with Airflow scheduling,
Jenkins CI/CD and MLflow tracking.

## Repository structure
```
├── notebooks/            # 3 Colab notebooks (regression, classification, recommender)
├── models/               # Trained artifacts (.pkl)
├── api/app.py            # Flask REST API (flight price prediction)
├── streamlit_app/app.py  # Streamlit dashboard (hotel recommender + insights)
├── airflow_dags/         # Weekly retraining DAG
├── mlflow_tracking/      # Training script with experiment tracking
├── k8s/deployment.yml    # Deployment + Service + HPA
├── Dockerfile            # API container image
├── Jenkinsfile           # CI/CD pipeline
├── tests/                # API smoke tests (run in CI)
└── requirements.txt
```

## Quickstart
```bash
# API (local)
python api/app.py
curl -X POST localhost:5000/predict -H "Content-Type: application/json" \
  -d '{"from":"Recife (PE)","to":"Florianopolis (SC)","flightType":"firstClass","agency":"FlyingDrops","time":1.76,"distance":676.53}'

# Docker
docker build -t flight-price-api .
docker run -p 5000:5000 flight-price-api

# Kubernetes
kubectl apply -f k8s/deployment.yml

# Streamlit
streamlit run streamlit_app/app.py

# MLflow
mlflow ui &
python mlflow_tracking/train_with_mlflow.py
```

Place `flights.csv`, `hotels.csv`, `users.csv` in a `data/` folder (not committed).
